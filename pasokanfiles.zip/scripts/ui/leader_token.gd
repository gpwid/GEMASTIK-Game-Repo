class_name LeaderToken
extends Button

## Nama file dan class dipertahankan agar scene lama tidak rusak.
## Token ini sekarang mewakili Expedition Leader, bukan kendaraan.

signal leader_drag_started(token: LeaderToken)
signal leader_drag_released(token: LeaderToken)

@export var leader_id: String = ""
@export var leader_name: String = "Pemimpin Ekspedisi"
@export var leader_color: Color = Color.WHITE
@export var icon_texture: Texture2D

@onready var vehicle_icon: TextureRect = $VehicleIcon

var is_dragging: bool = false
var inventory_position: Vector2


func _ready() -> void:
	pivot_offset = size / 2.0
	set_process(false)
	tooltip_text = leader_name

	if icon_texture != null:
		vehicle_icon.texture = icon_texture

	self_modulate = leader_color.lightened(0.45)


func _process(_delta: float) -> void:
	if is_dragging:
		global_position = get_global_mouse_position() - size / 2.0


func _gui_input(event: InputEvent) -> void:
	if event is not InputEventMouseButton:
		return

	var mouse_event := event as InputEventMouseButton
	if mouse_event.button_index != MOUSE_BUTTON_LEFT:
		return

	if mouse_event.pressed:
		begin_drag()
	else:
		end_drag()

	accept_event()


func begin_drag() -> void:
	if is_dragging:
		return

	is_dragging = true
	inventory_position = global_position
	z_index = 100
	scale = Vector2(1.08, 1.08)
	set_process(true)
	leader_drag_started.emit(self)


func end_drag() -> void:
	if not is_dragging:
		return

	is_dragging = false
	z_index = 0
	scale = Vector2.ONE
	set_process(false)
	leader_drag_released.emit(self)


func return_to_inventory() -> void:
	global_position = inventory_position
